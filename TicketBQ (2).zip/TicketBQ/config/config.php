<?php
    
    // $rootPath = 'https://atencion.grupoccima.com/';

    // $servidor = "localhost";
    // $usuario = "bbbme11_ccima";
    // $password = "GBUD0G2j6N*7";
    // $basedatos = "bbbme11_tickets";

    $rootPath = 'http://localhost/TicketBQ/';
    $servidor = "localhost";
    $usuario = "root";
    $password = "";
    $basedatos = "tickbq";
    
?>