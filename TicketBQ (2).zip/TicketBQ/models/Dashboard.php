<?php
    // class Dashboard extends Conectar{

    //     public function tick_abierto(){
    //         $conectar= parent::conexion();
    //         parent::set_names();
    //         $sql="SELECT COUNT(*) as cantidad FROM tm_ticket WHERE est = 1";
    //         $sql=$conectar->prepare($sql);
    //         $sql->execute();
    //         $resultado=$sql->fetchAll();
    //         return $resultado
    //     }
    // }


    
?>