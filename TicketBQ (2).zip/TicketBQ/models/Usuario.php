<?php
require_once("./config/conexion.php");
    class Usuario extends Conectar{

        public function login(){
            $conectar=parent::conexion();
            parent::set_names();
            if(isset($_POST["enviar"])){
                $correo = $_POST["usu_correo"];
                $pass = $_POST["usu_pass"];
                $rol = $_POST["rol_id"];
                if(empty($correo) and empty($pass)){
                    header("Location:".conectar::ruta()."index.php?m=2");
                    exit();
                } else {
                    $sql = "SELECT * FROM tm_usuario WHERE usu_correo=? and usu_pass =? and rol_id=? and est=1";
                    $stmt=$conectar->prepare($sql);
                    $stmt->bindValue(1, $correo);
                    $stmt->bindValue(2, $pass);
                    $stmt->bindValue(3, $rol);
                    $stmt->execute();
                    $resultado = $stmt->fetch();
                    if(is_array($resultado) and count($resultado)>0){
                        $_SESSION["usu_id"]=$resultado["usu_id"];
                        $_SESSION["usu_nom"]=$resultado["usu_nom"];
                        $_SESSION["usu_ape"]=$resultado["usu_ape"];
                        $_SESSION["rol_id"]=$resultado["rol_id"];
                        header("Location:".Conectar::ruta()."view/Home");
                        exit();
                    } else {
                        header("Location:".Conectar::ruta()."index.php?m=1");
                        exit();
                    }
                }

            }
        }

        public function verificarCorreoExistente($correo) {
            $conectar = parent::conexion();
            parent::set_names();
    
            $sql = "SELECT usu_id FROM tm_usuario WHERE usu_correo = ? AND est = 1";
            $stmt = $conectar->prepare($sql);
            $stmt->bindValue(1, $correo);
            $stmt->execute();
            $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
    
            // Si encuentra un resultado, significa que el correo existe
            return $resultado !== false;
        }

        public function obtenerCorreo($usu_id) {
            $conectar = $this->conexion();
            parent::set_names();
    
            $sql = "SELECT usu_correo FROM tm_usuario WHERE usu_id = ?";
            $stmt = $conectar->prepare($sql);
            $stmt->bindValue(1, $usu_id);
            $stmt->execute();
            $resultado = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($resultado) {
                return $resultado['usu_correo'];
            } else {
                return false;
            }
        }
        public function obtenerIdPorCorreo($correo) {
            $conectar = $this->conexion();
            parent::set_names();
        
            $sql = "SELECT usu_id FROM tm_usuario WHERE usu_correo = ?";
            $stmt = $conectar->prepare($sql);
            $stmt->bindValue(1, $correo);
            $stmt->execute();
            $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
        
            if ($resultado) {
                return $resultado['usu_id'];
            } else {
                return false;
            }
        }
        public function insertarToken($usu_id, $token) {
            $conectar = parent::conexion();
            parent::set_names();
    
            $sql = "INSERT INTO password_reset_tokens (user_id, token) VALUES (?, ?)";
            $stmt = $conectar->prepare($sql);
            $stmt->bindValue(1, $usu_id);
            $stmt->bindValue(2, $token);
            
            return $stmt->execute();
        }
    }
?>