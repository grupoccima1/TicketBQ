<div class="card">
  <div class="card-body">
    <div class="container">
    <div class="row">
    <div class="col">
    <div class= "card mt-4">
    <div class= "card-body">
    <a href="../index.php" class="btn btn-outline-info">
                        Volver a inicio de sesión 
                    </a>
        <h2> INGRESE SU CORREO ELECTRONICO  </h2>
        <form action="./validar_correo.php" method="post">
            <label for="usu_correo">CORREO</label>
            <input type="text" class="form-control" id="usu_correo" name="usu_correo">
          

           <button class="bt btn-primary mt-3">
                     Enviar contraseña
           </button>
                      
        </form>
        </div>
        </div>
        </div>
  </div>
</div>