<?php

// require_once '../models/Dashboard.php';

//     class DashboardController
//     {
        
//         public function getOpenTicketsCount()
//         {
//             $dashboard = new Dashboard();   
//             $openTicketsCount = $dashboard->tick_abierto();
//             return $openTicketsCount;
//         }
//     }

?>