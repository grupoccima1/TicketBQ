<div class="card">
    <div class="card-body">
        <div class="container">
            <div class="row">
                <div class="col">
                    <div class="card mt-4">
                        <div class="card-body">
                            <a href="../bbva.php" class="btn btn-outline-info">
                                Volver a inicio de sesión
                            </a>
                            <h2> CREAR NUEVA CONTRASEÑA </h2>
                            <form action="./actualizarcontrasena.php" method="post">
                                <div class="form-group">
                                    <label for="usu_contrasena">Nueva Contraseña</label>
                                    <input type="password" class="form-control" id="usu_contrasena" name="usu_contrasena" required>
                                </div>
                                <div class="form-group">
                                    <label for="confirmar_contrasena">Confirmar Contraseña</label>
                                    <input type="password" class="form-control" id="confirmar_contrasena" name="confirmar_contrasena" required>
                                </div>

                                <button class="btn btn-primary mt-3" type="submit">
                                    Guardar Contraseña
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>





